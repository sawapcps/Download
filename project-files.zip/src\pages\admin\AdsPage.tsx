import { useState, useEffect } from 'react'
import { useSettings } from '@/context/SettingsContext'
import { supabase } from '@/lib/supabase'
import type { Ad } from '@/types'
import { AD_PLACEMENTS } from '@/types'
import { Plus, Edit, Trash2, X, ExternalLink, Save, AlertCircle } from 'lucide-react'

export function AdsPage() {
  const { language } = useSettings()
  const [ads, setAds] = useState<Ad[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingAd, setEditingAd] = useState<Ad | null>(null)
  const [saving, setSaving] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  const emptyAd: Partial<Ad> = {
    title: '',
    title_ar: '',
    description: '',
    description_ar: '',
    image_url: '',
    link_url: '',
    button_text: 'Learn More',
    button_text_ar: 'اعرف المزيد',
    button_color: '#3b82f6',
    icon: '',
    sort_order: 0,
    start_date: null,
    end_date: null,
    is_active: true,
    open_in_new_tab: true,
    ad_type: 'banner',
    placement_slot: 'homepage_top',
  }

  const [formData, setFormData] = useState<Partial<Ad>>(emptyAd)

  useEffect(() => {
    loadAds()
  }, [])

  const loadAds = async () => {
    try {
      const { data, error } = await supabase
        .from('ads')
        .select('*')
        .order('sort_order', { ascending: true })

      if (!error && data) {
        setAds(data)
      }
    } catch (error) {
      console.error('Error loading ads:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!formData.title || !formData.link_url) return

    setSaving(true)

    try {
      if (editingAd) {
        const { error } = await supabase
          .from('ads')
          .update({
            ...formData,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingAd.id)

        if (error) throw error
      } else {
        const { error } = await supabase.from('ads').insert(formData)

        if (error) throw error
      }

      setShowModal(false)
      setEditingAd(null)
      setFormData(emptyAd)
      loadAds()
    } catch (error) {
      console.error('Error saving ad:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase.from('ads').delete().eq('id', id)

      if (error) throw error
      loadAds()
    } catch (error) {
      console.error('Error deleting ad:', error)
    } finally {
      setDeleteConfirm(null)
    }
  }

  const openEditModal = (ad: Ad) => {
    setEditingAd(ad)
    setFormData(ad)
    setShowModal(true)
  }

  const openAddModal = () => {
    setEditingAd(null)
    setFormData(emptyAd)
    setShowModal(true)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {language === 'ar' ? 'الإعلانات' : 'Ads Management'}
        </h1>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          {language === 'ar' ? 'إضافة إعلان' : 'Add Ad'}
        </button>
      </div>

      {/* Ads List */}
      <div className="space-y-4">
        {ads.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-gray-500 dark:text-gray-400">
              {language === 'ar' ? 'لا توجد إعلانات' : 'No ads found'}
            </p>
          </div>
        ) : (
          ads.map((ad) => (
            <div key={ad.id} className="card p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                {ad.image_url && (
                  <img
                    src={ad.image_url}
                    alt={ad.title}
                    className="w-full sm:w-32 h-24 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-gray-900 dark:text-white">
                        {language === 'ar' && ad.title_ar ? ad.title_ar : ad.title}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {language === 'ar' ? 'المكان:' : 'Placement:'}{' '}
                        {AD_PLACEMENTS.find((p) => p.id === ad.placement_slot)?.[language === 'ar' ? 'nameAr' : 'name'] || ad.placement_slot}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-1 rounded text-xs ${
                          ad.is_active
                            ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400'
                            : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
                        }`}
                      >
                        {ad.is_active
                          ? language === 'ar'
                            ? 'نشط'
                            : 'Active'
                          : language === 'ar'
                          ? 'غير نشط'
                          : 'Inactive'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <a
                      href={ad.link_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary-600 hover:underline flex items-center gap-1"
                    >
                      <ExternalLink className="w-4 h-4" />
                      {language === 'ar' ? 'فتح الرابط' : 'Open Link'}
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-2 sm:ml-4">
                  <button
                    onClick={() => openEditModal(ad)}
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <Edit className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(ad.id)}
                    className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  >
                    <Trash2 className="w-5 h-5 text-red-500" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b dark:border-gray-700 p-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingAd
                  ? language === 'ar'
                    ? 'تعديل الإعلان'
                    : 'Edit Ad'
                  : language === 'ar'
                  ? 'إضافة إعلان'
                  : 'Add Ad'}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    العنوان (إنجليزي)
                  </label>
                  <input
                    type="text"
                    value={formData.title || ''}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="input-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    العنوان (عربي)
                  </label>
                  <input
                    type="text"
                    value={formData.title_ar || ''}
                    onChange={(e) => setFormData({ ...formData, title_ar: e.target.value })}
                    className="input-primary"
                    dir="rtl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    الوصف (إنجليزي)
                  </label>
                  <textarea
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="input-primary"
                    rows={3}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    الوصف (عربي)
                  </label>
                  <textarea
                    value={formData.description_ar || ''}
                    onChange={(e) => setFormData({ ...formData, description_ar: e.target.value })}
                    className="input-primary"
                    rows={3}
                    dir="rtl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    رابط الصورة
                  </label>
                  <input
                    type="url"
                    value={formData.image_url || ''}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    className="input-primary"
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    رابط الإعلان *
                  </label>
                  <input
                    type="url"
                    value={formData.link_url || ''}
                    onChange={(e) => setFormData({ ...formData, link_url: e.target.value })}
                    className="input-primary"
                    placeholder="https://..."
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    نوع الإعلان
                  </label>
                  <select
                    value={formData.ad_type || 'banner'}
                    onChange={(e) => setFormData({ ...formData, ad_type: e.target.value as Ad['ad_type'] })}
                    className="input-primary"
                  >
                    <option value="banner">Banner</option>
                    <option value="popup">Popup</option>
                    <option value="floating">Floating</option>
                    <option value="inline">Inline</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    مكان الإعلان
                  </label>
                  <select
                    value={formData.placement_slot || ''}
                    onChange={(e) => setFormData({ ...formData, placement_slot: e.target.value })}
                    className="input-primary"
                  >
                    {AD_PLACEMENTS.map((p) => (
                      <option key={p.id} value={p.id}>
                        {language === 'ar' ? p.nameAr : p.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    نص الزر (إنجليزي)
                  </label>
                  <input
                    type="text"
                    value={formData.button_text || ''}
                    onChange={(e) => setFormData({ ...formData, button_text: e.target.value })}
                    className="input-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    نص الزر (عربي)
                  </label>
                  <input
                    type="text"
                    value={formData.button_text_ar || ''}
                    onChange={(e) => setFormData({ ...formData, button_text_ar: e.target.value })}
                    className="input-primary"
                    dir="rtl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    لون الزر
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={formData.button_color || '#3b82f6'}
                      onChange={(e) => setFormData({ ...formData, button_color: e.target.value })}
                      className="w-12 h-10 rounded-lg cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.button_color || ''}
                      onChange={(e) => setFormData({ ...formData, button_color: e.target.value })}
                      className="input-primary flex-1"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    تاريخ البداية
                  </label>
                  <input
                    type="date"
                    value={formData.start_date || ''}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    className="input-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    تاريخ النهاية
                  </label>
                  <input
                    type="date"
                    value={formData.end_date || ''}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                    className="input-primary"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="is_active"
                    checked={formData.is_active || false}
                    onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                  <label htmlFor="is_active" className="text-sm text-gray-700 dark:text-gray-300">
                    نشط
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="open_in_new_tab"
                    checked={formData.open_in_new_tab || false}
                    onChange={(e) => setFormData({ ...formData, open_in_new_tab: e.target.checked })}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                  <label htmlFor="open_in_new_tab" className="text-sm text-gray-700 dark:text-gray-300">
                    فتح في صفحة جديدة
                  </label>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    الترتيب
                  </label>
                  <input
                    type="number"
                    value={formData.sort_order || 0}
                    onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) })}
                    className="input-primary"
                  />
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 bg-white dark:bg-gray-800 border-t dark:border-gray-700 p-4 flex justify-end gap-3">
              <button
                onClick={() => setShowModal(false)}
                className="btn-secondary"
              >
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleSave}
                disabled={saving || !formData.title || !formData.link_url}
                className="btn-primary flex items-center gap-2"
              >
                {saving ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                {language === 'ar' ? 'حفظ' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-6">
            <div className="flex items-center gap-3 mb-4 text-red-600 dark:text-red-400">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-lg font-bold">
                {language === 'ar' ? 'تأكيد الحذف' : 'Confirm Delete'}
              </h3>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {language === 'ar'
                ? 'هل أنت متأكد من حذف هذا الإعلان؟'
                : 'Are you sure you want to delete this ad?'}
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="btn-secondary"
              >
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium transition-colors"
              >
                {language === 'ar' ? 'حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
