export function CategoriesPage() {
  return (
    <div className="card p-8 text-center">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Categories Management</h1>
      <p className="text-gray-500 dark:text-gray-400">Coming soon...</p>
    </div>
  )
}
