import { useState, useEffect } from 'react'
import { useSettings } from '@/context/SettingsContext'
import { supabase } from '@/lib/supabase'
import type { Link } from '@/types'
import { Plus, Edit, Trash2, X, ExternalLink, Save, AlertCircle } from 'lucide-react'

const PLACEMENTS = [
  { id: 'header', name: 'Header', nameAr: 'الهيدر' },
  { id: 'footer', name: 'Footer', nameAr: 'الفوتر' },
  { id: 'homepage', name: 'Homepage', nameAr: 'الصفحة الرئيسية' },
  { id: 'results', name: 'Results Page', nameAr: 'صفحة النتائج' },
  { id: 'download', name: 'Download Page', nameAr: 'صفحة التحميل' },
]

export function LinksPage() {
  const { language } = useSettings()
  const [links, setLinks] = useState<Link[]>([])
  const [linkPlacements, setLinkPlacements] = useState<Record<string, string[]>>({})
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingLink, setEditingLink] = useState<Link | null>(null)
  const [saving, setSaving] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [selectedPlacements, setSelectedPlacements] = useState<string[]>([])

  const emptyLink: Partial<Link> = {
    title: '',
    title_ar: '',
    description: '',
    description_ar: '',
    image_url: '',
    link_url: '',
    button_color: '#3b82f6',
    icon: '',
    sort_order: 0,
    is_active: true,
    open_in_new_tab: true,
  }

  const [formData, setFormData] = useState<Partial<Link>>(emptyLink)

  useEffect(() => {
    loadLinks()
  }, [])

  const loadLinks = async () => {
    try {
      const { data: linksData, error: linksError } = await supabase
        .from('links')
        .select('*')
        .order('sort_order', { ascending: true })

      const { data: placementsData } = await supabase
        .from('link_placements')
        .select('*')

      if (!linksError && linksData) {
        setLinks(linksData)

        // Group placements by link_id
        const grouped: Record<string, string[]> = {}
        if (placementsData) {
          placementsData.forEach((p: { link_id: string; placement: string }) => {
            if (!grouped[p.link_id]) {
              grouped[p.link_id] = []
            }
            grouped[p.link_id].push(p.placement)
          })
        }
        setLinkPlacements(grouped)
      }
    } catch (error) {
      console.error('Error loading links:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!formData.title || !formData.link_url) return

    setSaving(true)

    try {
      let linkId = editingLink?.id

      if (editingLink) {
        const { error } = await supabase
          .from('links')
          .update({
            ...formData,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingLink.id)

        if (error) throw error

        // Delete old placements
        await supabase.from('link_placements').delete().eq('link_id', editingLink.id)
      } else {
        const { data, error } = await supabase
          .from('links')
          .insert(formData)
          .select()
          .single()

        if (error) throw error
        linkId = data.id
      }

      // Add new placements
      if (linkId && selectedPlacements.length > 0) {
        const placements = selectedPlacements.map((p) => ({
          link_id: linkId,
          placement: p,
        }))
        await supabase.from('link_placements').insert(placements)
      }

      setShowModal(false)
      setEditingLink(null)
      setFormData(emptyLink)
      setSelectedPlacements([])
      loadLinks()
    } catch (error) {
      console.error('Error saving link:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      await supabase.from('link_placements').delete().eq('link_id', id)
      const { error } = await supabase.from('links').delete().eq('id', id)

      if (error) throw error
      loadLinks()
    } catch (error) {
      console.error('Error deleting link:', error)
    } finally {
      setDeleteConfirm(null)
    }
  }

  const openEditModal = (link: Link) => {
    setEditingLink(link)
    setFormData(link)
    setSelectedPlacements(linkPlacements[link.id] || [])
    setShowModal(true)
  }

  const openAddModal = () => {
    setEditingLink(null)
    setFormData(emptyLink)
    setSelectedPlacements([])
    setShowModal(true)
  }

  const togglePlacement = (placement: string) => {
    setSelectedPlacements((prev) =>
      prev.includes(placement) ? prev.filter((p) => p !== placement) : [...prev, placement]
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {language === 'ar' ? 'روابطي' : 'My Links'}
        </h1>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          {language === 'ar' ? 'إضافة رابط' : 'Add Link'}
        </button>
      </div>

      {/* Links List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {links.length === 0 ? (
          <div className="col-span-full card p-8 text-center">
            <p className="text-gray-500 dark:text-gray-400">
              {language === 'ar' ? 'لا توجد روابط' : 'No links found'}
            </p>
          </div>
        ) : (
          links.map((link) => (
            <div key={link.id} className="card p-4">
              <div className="flex items-start gap-3">
                {link.image_url && (
                  <img
                    src={link.image_url}
                    alt={link.title}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 dark:text-white">
                    {language === 'ar' && link.title_ar ? link.title_ar : link.title}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mt-1">
                    {language === 'ar' && link.description_ar ? link.description_ar : link.description}
                  </p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {(linkPlacements[link.id] || []).map((p) => (
                      <span
                        key={p}
                        className="px-2 py-0.5 text-xs rounded bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
                      >
                        {PLACEMENTS.find((pl) => pl.id === p)?.[language === 'ar' ? 'nameAr' : 'name'] || p}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4 pt-4 border-t dark:border-gray-700">
                <a
                  href={link.link_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-primary-600 hover:underline flex items-center gap-1"
                >
                  <ExternalLink className="w-4 h-4" />
                  {language === 'ar' ? 'فتح' : 'Open'}
                </a>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(link)}
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <Edit className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(link.id)}
                    className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  >
                    <Trash2 className="w-5 h-5 text-red-500" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white dark:bg-gray-800 border-b dark:border-gray-700 p-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingLink
                  ? language === 'ar'
                    ? 'تعديل الرابط'
                    : 'Edit Link'
                  : language === 'ar'
                  ? 'إضافة رابط'
                  : 'Add Link'}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  العنوان (إنجليزي) *
                </label>
                <input
                  type="text"
                  value={formData.title || ''}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="input-primary"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  العنوان (عربي)
                </label>
                <input
                  type="text"
                  value={formData.title_ar || ''}
                  onChange={(e) => setFormData({ ...formData, title_ar: e.target.value })}
                  className="input-primary"
                  dir="rtl"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الوصف
                </label>
                <textarea
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="input-primary"
                  rows={2}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  رابط الصورة
                </label>
                <input
                  type="url"
                  value={formData.image_url || ''}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  className="input-primary"
                  placeholder="https://..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الرابط *
                </label>
                <input
                  type="url"
                  value={formData.link_url || ''}
                  onChange={(e) => setFormData({ ...formData, link_url: e.target.value })}
                  className="input-primary"
                  placeholder="https://..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  أماكن الظهور
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {PLACEMENTS.map((p) => (
                    <label
                      key={p.id}
                      className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedPlacements.includes(p.id)
                          ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={selectedPlacements.includes(p.id)}
                        onChange={() => togglePlacement(p.id)}
                        className="w-4 h-4 rounded border-gray-300"
                      />
                      <span className="text-sm">
                        {language === 'ar' ? p.nameAr : p.name}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="link_active"
                    checked={formData.is_active || false}
                    onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                  <label htmlFor="link_active" className="text-sm text-gray-700 dark:text-gray-300">
                    نشط
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="link_new_tab"
                    checked={formData.open_in_new_tab || false}
                    onChange={(e) => setFormData({ ...formData, open_in_new_tab: e.target.checked })}
                    className="w-4 h-4 rounded border-gray-300"
                  />
                  <label htmlFor="link_new_tab" className="text-sm text-gray-700 dark:text-gray-300">
                    صفحة جديدة
                  </label>
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 bg-white dark:bg-gray-800 border-t dark:border-gray-700 p-4 flex justify-end gap-3">
              <button onClick={() => setShowModal(false)} className="btn-secondary">
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleSave}
                disabled={saving || !formData.title || !formData.link_url}
                className="btn-primary flex items-center gap-2"
              >
                {saving ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                {language === 'ar' ? 'حفظ' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-6">
            <div className="flex items-center gap-3 mb-4 text-red-600 dark:text-red-400">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-lg font-bold">
                {language === 'ar' ? 'تأكيد الحذف' : 'Confirm Delete'}
              </h3>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {language === 'ar'
                ? 'هل أنت متأكد من حذف هذا الرابط؟'
                : 'Are you sure you want to delete this link?'}
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="btn-secondary">
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium transition-colors"
              >
                {language === 'ar' ? 'حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
