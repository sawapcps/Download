import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { supabase } from '@/lib/supabase'
import type { SiteSettings } from '@/types'

interface SettingsContextType {
  settings: SiteSettings | null
  loading: boolean
  darkMode: boolean
  language: 'ar' | 'en'
  toggleDarkMode: () => void
  toggleLanguage: () => void
  setLanguage: (lang: 'ar' | 'en') => void
  t: (key: string, arText: string, enText?: string) => string
  refreshSettings: () => Promise<void>
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [darkMode, setDarkMode] = useState(true)
  const [language, setLanguage] = useState<'ar' | 'en'>('ar')

  const refreshSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('*')
        .maybeSingle()

      if (error) throw error
      if (data) {
        setSettings(data)
        setLanguage(data.default_language || 'ar')
        setDarkMode(data.dark_mode_default ?? true)
      }
    } catch (error) {
      console.error('Error loading settings:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refreshSettings()
  }, [])

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [darkMode])

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr'
    document.documentElement.lang = language
  }, [language])

  const toggleDarkMode = () => {
    setDarkMode(prev => !prev)
  }

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'ar' ? 'en' : 'ar')
  }

  const t = (_key: string, arText: string, enText?: string): string => {
    return language === 'ar' ? arText : (enText || arText)
  }

  return (
    <SettingsContext.Provider value={{
      settings,
      loading,
      darkMode,
      language,
      toggleDarkMode,
      toggleLanguage,
      setLanguage,
      t,
      refreshSettings,
    }}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider')
  }
  return context
}
