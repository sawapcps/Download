import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import type { Admin } from '@/types'

interface AdminContextType {
  admin: Admin | null
  loading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
  isAuthenticated: boolean
  sessionExpiring: boolean
  extendSession: () => void
}

const AdminContext = createContext<AdminContextType | undefined>(undefined)

const SESSION_KEY = 'admin_session'
const SESSION_TIMEOUT = 30 * 60 * 1000 // 30 minutes
const SESSION_WARNING = 5 * 60 * 1000 // 5 minutes before expiry

export function AdminProvider({ children }: { children: ReactNode }) {
  const [admin, setAdmin] = useState<Admin | null>(null)
  const [loading, setLoading] = useState(true)
  const [sessionExpiring, setSessionExpiring] = useState(false)

  const checkSession = useCallback(async () => {
    try {
      const sessionData = localStorage.getItem(SESSION_KEY)
      if (sessionData) {
        const session = JSON.parse(sessionData)
        const now = Date.now()

        if (session.expires > now) {
          // Check if session is about to expire
          if (session.expires - now < SESSION_WARNING) {
            setSessionExpiring(true)
          }

          const { data, error } = await supabase
            .from('admins')
            .select('id, email, name, role, is_active, last_login, created_at')
            .eq('id', session.adminId)
            .eq('is_active', true)
            .maybeSingle()

          if (!error && data) {
            setAdmin(data as Admin)
          } else {
            localStorage.removeItem(SESSION_KEY)
          }
        } else {
          // Session expired
          localStorage.removeItem(SESSION_KEY)
          setAdmin(null)
        }
      }
    } catch (error) {
      console.error('Session check error:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    checkSession()

    // Check session every minute
    const interval = setInterval(checkSession, 60000)

    // Auto-logout on inactivity
    let inactivityTimer: number | null = null

    const resetInactivityTimer = () => {
      if (inactivityTimer) clearTimeout(inactivityTimer)
      inactivityTimer = window.setTimeout(() => {
        if (admin) {
          logout()
        }
      }, SESSION_TIMEOUT)
    }

    // Activity listeners
    const events = ['mousedown', 'keydown', 'touchstart', 'scroll']
    events.forEach(event => {
      document.addEventListener(event, resetInactivityTimer)
    })

    return () => {
      clearInterval(interval)
      events.forEach(event => {
        document.removeEventListener(event, resetInactivityTimer)
      })
      if (inactivityTimer) clearTimeout(inactivityTimer)
    }
  }, [checkSession, admin])

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase
        .from('admins')
        .select('id, email, name, role, is_active, last_login, created_at, password_hash')
        .eq('email', email)
        .eq('is_active', true)
        .maybeSingle()

      if (error) {
        return { success: false, error: 'Database error' }
      }

      if (!data) {
        return { success: false, error: 'Invalid email or password' }
      }

      const isValid = await verifyPassword(password, data.password_hash)

      if (!isValid) {
        return { success: false, error: 'Invalid email or password' }
      }

      // Update last login
      await supabase
        .from('admins')
        .update({ last_login: new Date().toISOString() })
        .eq('id', data.id)

      // Create session with 24 hour expiry
      const session = {
        adminId: data.id,
        expires: Date.now() + SESSION_TIMEOUT,
      }
      localStorage.setItem(SESSION_KEY, JSON.stringify(session))

      const adminData = { ...data, password_hash: '' } as unknown as Admin
      setAdmin(adminData)
      setSessionExpiring(false)

      // Log activity
      await supabase.from('activity_logs').insert({
        admin_id: data.id,
        action: 'login',
        details: { email },
      })

      return { success: true }
    } catch (error) {
      console.error('Login error:', error)
      return { success: false, error: 'An unexpected error occurred' }
    }
  }

  const verifyPassword = async (password: string, storedHash: string): Promise<boolean> => {
    const encoder = new TextEncoder()
    const data = encoder.encode(password)
    const hashBuffer = await crypto.subtle.digest('SHA-256', data)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const computedHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
    return computedHash === storedHash
  }

  const logout = async () => {
    if (admin) {
      await supabase.from('activity_logs').insert({
        admin_id: admin.id,
        action: 'logout',
      })
    }
    localStorage.removeItem(SESSION_KEY)
    setAdmin(null)
    setSessionExpiring(false)
  }

  const extendSession = () => {
    const sessionData = localStorage.getItem(SESSION_KEY)
    if (sessionData) {
      const session = JSON.parse(sessionData)
      session.expires = Date.now() + SESSION_TIMEOUT
      localStorage.setItem(SESSION_KEY, JSON.stringify(session))
      setSessionExpiring(false)
    }
  }

  return (
    <AdminContext.Provider value={{
      admin,
      loading,
      login,
      logout,
      isAuthenticated: !!admin,
      sessionExpiring,
      extendSession,
    }}>
      {children}
    </AdminContext.Provider>
  )
}

export function useAdmin() {
  const context = useContext(AdminContext)
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider')
  }
  return context
}
