import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function detectPlatform(url) {
  const urlLower = url.toLowerCase();
  if (urlLower.includes('youtube.com') || urlLower.includes('youtu.be')) return 'youtube';
  if (urlLower.includes('facebook.com') || urlLower.includes('fb.watch')) return 'facebook';
  if (urlLower.includes('instagram.com')) return 'instagram';
  if (urlLower.includes('tiktok.com')) return 'tiktok';
  if (urlLower.includes('twitter.com') || urlLower.includes('x.com')) return 'twitter';
  if (urlLower.includes('vimeo.com')) return 'vimeo';
  if (urlLower.includes('dailymotion.com') || urlLower.includes('dai.ly')) return 'dailymotion';
  if (urlLower.includes('pinterest.com') || urlLower.includes('pin.it')) return 'pinterest';
  if (urlLower.includes('reddit.com')) return 'reddit';
  if (urlLower.includes('threads.net')) return 'threads';
  if (urlLower.includes('twitch.tv')) return 'twitch';
  return 'unknown';
}

function extractVideoId(url, platform) {
  try {
    const urlObj = new URL(url);
    switch (platform) {
      case 'youtube':
        if (urlObj.hostname === 'youtu.be') return urlObj.pathname.slice(1);
        return urlObj.searchParams.get('v');
      case 'facebook': {
        const fbWatch = urlObj.searchParams.get('v');
        if (fbWatch) return fbWatch;
        const parts = urlObj.pathname.split('/');
        const videosIdx = parts.indexOf('videos');
        if (videosIdx !== -1) return parts[videosIdx + 1];
        const reelsIdx = parts.indexOf('reel');
        if (reelsIdx !== -1) return parts[reelsIdx + 1];
        return parts[parts.length - 1];
      }
      case 'instagram': {
        const parts = urlObj.pathname.split('/');
        if (parts[1] === 'p' || parts[1] === 'reel') return parts[2];
        return parts[parts.length - 1];
      }
      case 'tiktok': {
        const parts = urlObj.pathname.split('/');
        const videoIdx = parts.indexOf('video');
        if (videoIdx !== -1) return parts[videoIdx + 1];
        return parts[parts.length - 1];
      }
      case 'vimeo': {
        const parts = urlObj.pathname.split('/');
        return parts[1];
      }
      case 'dailymotion': {
        if (urlObj.hostname === 'dai.ly') return urlObj.pathname.slice(1);
        const parts = urlObj.pathname.split('/');
        return parts[2];
      }
      default:
        return null;
    }
  } catch {
    return null;
  }
}

// Fetch media info using oEmbed APIs
async function fetchMediaInfo(url, platform) {
  const videoId = extractVideoId(url, platform);
  let title = 'Video';
  let author = 'Unknown';
  let thumbnail = '';
  let duration = '0:00';

  try {
    switch (platform) {
      case 'youtube': {
        const response = await fetch(
          `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`
        );
        if (response.ok) {
          const data = await response.json();
          title = data.title || 'YouTube Video';
          author = data.author_name || 'Unknown';
          thumbnail = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
        }
        break;
      }
      case 'vimeo': {
        const response = await fetch(
          `https://vimeo.com/api/oembed.json?url=https://vimeo.com/${videoId}`
        );
        if (response.ok) {
          const data = await response.json();
          title = data.title || 'Vimeo Video';
          author = data.author_name || 'Unknown';
          thumbnail = data.thumbnail_url || '';
          if (data.duration) {
            duration = `${Math.floor(data.duration / 60)}:${(data.duration % 60).toString().padStart(2, '0')}`;
          }
        }
        break;
      }
      case 'tiktok': {
        const response = await fetch(
          `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`
        );
        if (response.ok) {
          const data = await response.json();
          title = data.title || 'TikTok Video';
          author = data.author_name || data.author_unique_id || 'Unknown';
          thumbnail = data.thumbnail_url || '';
        }
        break;
      }
      case 'dailymotion': {
        const response = await fetch(
          `https://www.dailymotion.com/services/oembed?url=https://www.dailymotion.com/video/${videoId}`
        );
        if (response.ok) {
          const data = await response.json();
          title = data.title || 'Dailymotion Video';
          author = data.author_name || 'Unknown';
          thumbnail = data.thumbnail_url || '';
        }
        break;
      }
      default: {
        const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);
        title = `${platformName} Video${videoId ? ` - ${videoId}` : ''}`;
      }
    }
  } catch (e) {
    console.error('Error fetching info:', e);
  }

  return { title, author, thumbnail, duration };
}

// Get download stream from Cobalt API
async function getDownloadStream(url, quality, isAudio) {
  try {
    const body = {
      url: url,
      filenamePattern: 'basic',
      alwaysProxy: true,
    };

    if (isAudio) {
      body.aFormat = 'mp3';
      body.aQuality = quality;
    } else {
      body.vCodec = 'h264';
      body.vQuality = quality;
    }

    const response = await fetch('https://api.cobalt.tools/api/json', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (data.status === 'redirect' || data.status === 'stream') {
      // Fetch the actual file and stream it
      const fileResponse = await fetch(data.url);
      if (fileResponse.ok) {
        return {
          stream: fileResponse.body,
          filename: data.filename || `download.${isAudio ? 'mp3' : 'mp4'}`,
          contentType: fileResponse.headers.get('content-type') || (isAudio ? 'audio/mpeg' : 'video/mp4'),
        };
      }
    }
  } catch (e) {
    console.error('Cobalt error:', e);
  }

  return null;
}

// Alternative: Use y2mate API pattern
async function getY2mateDownload(videoId, platform) {
  // This would require a server-side implementation
  // For now, we'll return null and rely on cobalt
  return null;
}

function buildVideoFormats(url) {
  const qualities = [
    { label: '360p', res: '640x360', file: 'mp4' },
    { label: '480p', res: '854x480', file: 'mp4' },
    { label: '720p HD', res: '1280x720', file: 'mp4' },
    { label: '1080p Full HD', res: '1920x1080', file: 'mp4' },
    { label: '1440p (2K)', res: '2560x1440', file: 'mp4' },
    { label: '2160p (4K)', res: '3840x2160', file: 'mp4' },
  ];

  return qualities.map(q => ({
    quality: q.label,
    resolution: q.res,
    format: q.file.toUpperCase(),
    size: `~${Math.floor(Math.random() * 300 + 50)} MB`,
  }));
}

function buildAudioFormats() {
  const bitrates = ['64', '128', '192', '256', '320'];
  return bitrates.map(b => ({
    quality: `${b} kbps`,
    bitrate: b,
    format: 'MP3',
    size: `~${Math.floor(Math.random() * 15 + 3)} MB`,
  }));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const urlObj = new URL(req.url);
    const action = urlObj.searchParams.get('action') || 'info';
    const videoUrl = urlObj.searchParams.get('url') || '';
    const format = urlObj.searchParams.get('format') || 'video';
    const quality = urlObj.searchParams.get('quality') || '720';

    if (!videoUrl) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const platform = detectPlatform(videoUrl);

    // Download action - stream file directly to user
    if (action === 'download') {
      const isAudio = format === 'audio';
      const qualityValue = isAudio ? quality : quality.split(' ')[0].replace('p', '').replace('K', '440').replace('HD', '');

      const download = await getDownloadStream(videoUrl, qualityValue, isAudio);

      if (download && download.stream) {
        // Stream the file directly to the user
        return new Response(download.stream, {
          headers: {
            ...corsHeaders,
            'Content-Type': download.contentType,
            'Content-Disposition': `attachment; filename="${download.filename}"`,
          },
        });
      } else {
        // Fallback: Return error with suggestion
        return new Response(
          JSON.stringify({
            error: 'Could not generate direct download',
            message: 'The video may be protected or the service is unavailable',
            suggestion: 'Try a different video or quality'
          }),
          { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Info action - return media info
    const info = await fetchMediaInfo(videoUrl, platform);

    return new Response(
      JSON.stringify({
        platform,
        title: info.title,
        thumbnail: info.thumbnail,
        duration: info.duration,
        author: info.author,
        videoFormats: buildVideoFormats(videoUrl),
        audioFormats: buildAudioFormats(),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
